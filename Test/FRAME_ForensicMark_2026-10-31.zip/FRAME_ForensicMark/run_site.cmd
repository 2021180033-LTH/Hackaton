@echo off
chcp 65001 >nul
rem FRAME 업로드 사이트 실행: 판정 서버(ForensicMark site, 8090번)를 켜고 브라우저로 사이트를 연다. 서버 창을 닫으면 끝난다.
rem 8090번을 잡고 있는 예전 판정 서버는 먼저 닫아서, 사이트가 항상 지금 빌드와 통신하게 한다.
cd /d "%~dp0"

rem ffmpeg 확인: settings.ini의 경로, 이 폴더의 ffmpeg.exe, PATH 중 하나에 있으면 된다
set "FF="
for /f "tokens=1,* delims==" %%a in ('findstr /b /i "ffmpeg=" settings.ini 2^>nul') do set "FF=%%b"
set "FOUND="
if defined FF if exist "%FF%" set FOUND=1
if exist "%~dp0ffmpeg.exe" set FOUND=1
where ffmpeg >nul 2>&1 && set FOUND=1
if not defined FOUND (
    echo.
    echo  [FRAME] ffmpeg를 찾을 수 없어요.
    echo    1^) 이 창에서:  winget install Gyan.FFmpeg
    echo    2^) 설치가 끝나면 이 창을 닫고 run_site.cmd를 다시 실행하세요.
    echo    또는 ffmpeg.exe와 ffprobe.exe를 이 폴더에 넣어도 됩니다.
    echo.
    pause
    exit /b 1
)

for /f "tokens=5" %%p in ('netstat -ano ^| findstr /r /c:":8090 .*LISTENING"') do (
    tasklist /fi "pid eq %%p" | find /i "ForensicMark.exe" >nul && taskkill /f /pid %%p >nul 2>&1
)
start "FRAME judge server" ForensicMark.exe site
timeout /t 2 /nobreak >nul
start "" http://127.0.0.1:8090/
